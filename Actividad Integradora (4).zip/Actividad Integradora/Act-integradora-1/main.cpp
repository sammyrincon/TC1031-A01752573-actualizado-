/*
 * Archivo: main.cpp
 * Descripción: Procesamiento de bitácora de acceso a red (ordenamiento, búsqueda, diferencia de días).
 * Samuel Rincon v  A01752573
 * 3/24/2025
 * Fuentes: Estructura de ordenamiento y temporización basada en ejemplos del profesor y GeeksForGeeks.
 *
 * Compilación:
 *    g++ -std=c++17 -Wall -O3 -o bitacoraApp main.cpp BitacoraEntry.cpp
 *
 * Ejecución:
 *    ./bitacoraApp < test01.txt
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <chrono>
#include "BitacoraEntry.h"


using std::cin;
using std::cout;
using std::endl;
using std::vector;
using std::string;


long long comparaciones = 0;
long long intercambios = 0;

void leerBitacora (const string& archivoEntrada, vector<BitacoraEntry>& bitacora)
{
    std::ifstream archivo(archivoEntrada);
    string linea;

    while (std::getline(archivo, linea))
    {
        std::istringstream ss(linea);
        string mes, horaCompleta, ip, razon;
        int dia, h, min, s;

        ss >> mes >> dia >> horaCompleta >> ip;
        std::getline(ss, razon);
        h = std::stoi(horaCompleta.substr(0, 2));
        min = std::stoi(horaCompleta.substr(3, 2));
        s = std::stoi(horaCompleta.substr(6, 2));

        bitacora.push_back(BitacoraEntry(mes, dia, h, min, s, ip, razon));
    }
}

void merge(vector<BitacoraEntry>& a, int left, int mid, int right) 
{
    vector<BitacoraEntry> temp(right - left + 1);
    int i = left, j = mid + 1, k = 0;
  
    while (i <= mid && j <= right) 
    {
      if (a[i] < a[j]) 
      {
        temp[k++] = a[i++];
      } 
      else 
      {
        temp[k++] = a[j++];
        intercambios++;
      }
    }
    while (i <= mid) temp[k++] = a[i++];
    while (j <= right) temp[k++] = a[j++];
  
    for (int t = 0; t < k; ++t) 
    {
      a[left + t] = temp[t];
    }
}

void mergeSort(vector<BitacoraEntry>& a, int left, int right) {
    if (left < right) {
      int mid = (left + right) / 2;
      mergeSort(a, left, mid);
      mergeSort(a, mid + 1, right);
      merge(a, left, mid, right);
    }
  }
  

  int buscarFecha(const vector<BitacoraEntry>& bitacora, const string& fecha) {
    for (const BitacoraEntry& entry : bitacora) {
      if (entry.getFechaCompleta() == fecha) {
        return &entry - &bitacora[0];
      }
    }
    return -1;
  }
  
 
  std::pair<int, int> buscarPorDias(const vector<BitacoraEntry>& bitacora, int d) {
    for (size_t i = 0; i < bitacora.size(); ++i) {
      for (size_t j = i + 1; j < bitacora.size(); ++j) {
        double diff = difftime(bitacora[j].toTimeT(), bitacora[i].toTimeT());
        if (diff >= d * 86400 && diff < (d + 1) * 86400) {
          return { (int)i, (int)j };
        }
        if (diff > (d + 1) * 86400) break;
      }
    }
    return { -1, -1 };
  }
  
  int main() {
    vector<BitacoraEntry> bitacora;
  
   
    leerBitacora("bitacoraData.txt", bitacora);
  
  
    comparaciones = 0;
    intercambios = 0;
  
    auto start = std::chrono::high_resolution_clock::now();
    mergeSort(bitacora, 0, bitacora.size() - 1);
    auto end = std::chrono::high_resolution_clock::now();
    auto tiempo = end - start;
  

    std::ofstream outOrdenada("bitacora_ordenada.txt");
    for (const BitacoraEntry& e : bitacora) {
      outOrdenada << e.toString() << endl;
    }
 
    int b;
    cin >> b;
    vector<string> fechas;
    cin.ignore();
  
    for (int i = 0; i < b; ++i) {
      string f;
      std::getline(cin, f);
      fechas.push_back(f);
    }
  
    int d;
    cin >> d;
  
    std::ofstream outResultados("resultados_busqueda.txt");
    int exitosas = 0;
  
    for (const string& f : fechas) {
      int idx = buscarFecha(bitacora, f);
      if (idx != -1) {
        outResultados << "[" << idx << "] " << bitacora[idx].toString() << endl;
        exitosas++;
      } else {
        outResultados << "Fecha no encontrada: " << f << endl;
      }
    }
  
    outResultados << endl;
    outResultados << "Busqueda del primer par de registros con " << d << " dias de diferencia:" << endl;
    std::pair<int, int> par = buscarPorDias(bitacora, d);
  
    if (par.first != -1) {
      outResultados << "[" << par.first << "] " << bitacora[par.first].toString() << endl;
      outResultados << "[" << par.second << "] " << bitacora[par.second].toString() << endl;
    } else {
      outResultados << "No existe dicho par de registros" << endl;
    }
  
  
    cout << "Merge Sort" << endl;
    cout << comparaciones << endl;
    cout << intercambios << endl;
    cout << endl;
    cout << b << endl;
    cout << exitosas << endl;
    cout << b - exitosas << endl;
    cout << endl;
    cout << "Busqueda del primer par de registros con " << d << " dias de diferencia:" << endl;
  
    if (par.first != -1) {
      cout << "[" << par.first << "] " << bitacora[par.first].toString() << endl;
      cout << "[" << par.second << "] " << bitacora[par.second].toString() << endl;
    } else {
      cout << "No existe dicho par de registros" << endl;
    }
  
    cout << "Tiempo de ejecución en ms: " << tiempo / std::chrono::milliseconds(1) << endl;
  
    return 0;
  }