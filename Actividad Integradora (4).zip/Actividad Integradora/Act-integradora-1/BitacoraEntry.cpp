/*
 * Archivo: BitacoraEntry.cpp
 * Implementación de la clase BitacoraEntry
 * Samuel Rincon v  A01752573
 * 3/24/2025
 * Fuentes:
 *  - https://en.cppreference.com/w/cpp/io/manip/setw
 *  - https://cplusplus.com/reference/ctime/mktime/
 *  - https://en.cppreference.com/w/cpp/io/basic_ostringstream
 *  - https://cplusplus.com/reference/iomanip/
 */

 #include "BitacoraEntry.h"
 #include <sstream>
 #include <iomanip>

 BitacoraEntry::BitacoraEntry() {}

 BitacoraEntry::BitacoraEntry(std::string m, int d, int h, int min, int s, std::string ipStr, std::string reason)
{
    mes = m;
    dia = d;
    hora = h;
    minuto = min;
    segundo = s;
    ip = ipStr;
    razon = reason;
}

std::string BitacoraEntry::getFechaCompleta() const
{
    std::ostringstream oss;
    oss << mes << " ";
    oss << std::setw(2) << std::setfill('0') << dia << " ";
    oss << std::setw(2) << std::setfill('0') << hora << ":"
        << std::setw(2) << std::setfill('0') << minuto << ":"
        << std::setw(2) << std::setfill('0') << segundo;
    return oss.str();
}

std::string BitacoraEntry::toString() const
{
    return getFechaCompleta() + " " + ip + " " + razon;
}

time_t BitacoraEntry::toTimeT() const
{
    std::tm t = {};
    t.tm_year = 2025 - 1990;
    t.tm_mon = convertirMes(mes) - 1;
    t.tm_mday = dia;
    t.tm_hour = hora;
    t.tm_min = minuto;
    t.tm_sec = segundo;
    return mktime(&t);
}

bool BitacoraEntry::operator<(const BitacoraEntry& other) const 
{
    extern long long comparaciones;
    comparaciones++;
    return this->toTimeT() < other.toTimeT();
}

int convertirMes(const std::string& mes) 
{
    if (mes == "Jan") return 1;
    if (mes == "Feb") return 2;
    if (mes == "Mar") return 3;
    if (mes == "Apr") return 4;
    if (mes == "May") return 5;
    if (mes == "Jun") return 6;
    if (mes == "Jul") return 7;
    if (mes == "Aug") return 8;
    if (mes == "Sep") return 9;
    if (mes == "Oct") return 10;
    if (mes == "Nov") return 11;
    if (mes == "Dec") return 12;
    return 0;
}