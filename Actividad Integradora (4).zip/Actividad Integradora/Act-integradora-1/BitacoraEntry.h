/*
 * Archivo: BitacoraEntry.h
 * Descripción: Declaración de la clase BitacoraEntry para representar registros de acceso a la red.
 *  Samuel Rincon V.  A01752573
 * 3/24/2025
 * Fuentes: Conversión de fechas y sobrecarga de operadores inspiradas en ejemplos de GeeksForGeeks.
 *  -  https://www.geeksforgeeks.org/convert-string-time-tm-structure-c/
 *  -  https://www.geeksforgeeks.org/operator-overloading-c/
 * 
 * 
 * Complejidades:
 *  - getFechaCompleta: O(1)
 *  - toString: O(1)
 *  - toTimeT: O(1)
 *  - operator<: O(1)
 * 
 */

 #ifndef BITACORAENTRY_H
 #define BITACORAENTRY_H


 #include <string>
 #include <ctime>

 class BitacoraEntry 
 {
    private:
        std::string mes;
        int dia;
        int hora;
        int minuto;
        int segundo;
        std::string ip;
        std::string razon;

    public:
        BitacoraEntry();
        BitacoraEntry(std::string m, int d, int h, int min, int s, std::string ipStr, std::string reason);

        std::string getFechaCompleta() const;
        std::string toString() const;
        time_t toTimeT() const;

        bool operator < (const BitacoraEntry& other) const;
 };
 
 int convertirMes(const std::string& mes);

 #endif 