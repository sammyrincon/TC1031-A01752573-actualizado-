/*
 * Actividad Integradora 4 - TC1031
 * Autor: Samuel Rincón V. - A01752573
 * Fecha: 05/28/25
 * 
 * Instrucciones para compilar:
 *   g++ -std=c++11 -Wall -O2 -o main.exe main.cpp
 * 
 * Instrucciones para ejecutar:
 *   main.exe < bitacoraGrafos.txt
 *
 * Fuentes:
 * - https://www.cplusplus.com/doc/tutorial/files/
 * - https://cplusplus.com/reference/fstream/ifstream/
 * - https://cplusplus.com/reference/vector/vector/
 * - https://cplusplus.com/reference/string/string/
 * - https://cplusplus.com/reference/iostream/
 */

#include <fstream>
#include <iostream>
#include "Graph.h"

int main() {
    std::ifstream bitacora("bitacoraGrafos.txt");
    Graph g;
    g.loadGraph(bitacora);

    g.saveOutDegrees("grados_ips.txt");

    std::string botmaster;
    g.saveTop5OutDegrees("mayores_grados_ips.txt", botmaster);
    std::cout << "Botmaster sospechoso: " << botmaster << "\n";

    std::ifstream bitacora2("bitacoraGrafos.txt");
    Graph g2;
    g2.loadGraph(bitacora2);
    std::ifstream bitacora3("bitacoraGrafos.txt");
    std::string primeraConexion = g2.findFirstConnection(bitacora3, botmaster);
    std::cout << "Primera conexion del botmaster: " << primeraConexion << "\n";

    std::vector<int> distancias = g.dijkstra(botmaster);
    g.saveDistances("distancia_botmaster.txt", distancias);

    int idxLejano = g.findFarthestIp(distancias);
    std::string ipLejana = g.getIpFromIndex(idxLejano);
    std::cout << "IP mas dificil de atacar: " << ipLejana << "\n";

    g.savePath("ataque_botmaster.txt", botmaster, ipLejana);

    return 0;
}
