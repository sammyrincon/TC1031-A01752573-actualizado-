/*
 * Actividad Integradora 4
 * Autor: Samuel Rincón V. - A01752573
 * Fecha: 05/28/25
 * 
 * Instrucciones para compilar:
 *   g++ -std=c++11 -Wall -O2 -o main.exe main.cpp
 * 
 * Instrucciones para ejecutar:
 *   main.exe < bitacoraGrafos.txt
 *
 * Fuentes:
 * - https://cplusplus.com/reference/cstring/strtok/
 * - https://cplusplus.com/reference/sstream/istringstream/
 * - https://www.cplusplus.com/doc/tutorial/strings/
 * - https://www.programiz.com/cpp-programming/library-function/cstring/strtok
 * - Stroustrup, B. (2013). The C++ Programming Language (4th ed.). Addison-Wesley.
 */

#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <sstream>

int mesAInt(const std::string& mes) {
    if (mes == "Jan") return 1;
    if (mes == "Feb") return 2;
    if (mes == "Mar") return 3;
    if (mes == "Apr") return 4;
    if (mes == "May") return 5;
    if (mes == "Jun") return 6;
    if (mes == "Jul") return 7;
    if (mes == "Aug") return 8;
    if (mes == "Sep") return 9;
    if (mes == "Oct") return 10;
    if (mes == "Nov") return 11;
    if (mes == "Dec") return 12;
    return 0;
}

std::string limpiarIP(const std::string& ipConPuerto) {
    size_t pos = ipConPuerto.find(':');
    return ipConPuerto.substr(0, pos);
}

std::string formatearFecha(const std::string& mes, const std::string& dia, const std::string& hora) {
    std::ostringstream ss;
    ss << mes << " " << dia << " " << hora;
    return ss.str();
}

#endif
