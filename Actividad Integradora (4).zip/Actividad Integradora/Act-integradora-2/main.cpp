/*
 * Act-Integradora-2
 * Samuel Rincón V. - A01752573
 * Fecha: 7 de abril de 2025
 *
 * compilación:
 *   g++ -std=c++17 -Wall -O3 -o main main.cpp
 * 
 *  ejecución:
 *   ./main
 *
 * Fuentes:
 * - https://cplusplus.com/reference/sstream/istringstream/
 * - https://cplusplus.com/reference/iomanip/
 */

 #include <iostream>
 #include <fstream>
 #include <algorithm>
 #include <sstream>
 #include <string>
 #include "BitacoraEntry.h"
 #include "DoublyLinkedList.h"


 BitacoraEntry parseLine(const std::string& line) {
     std::istringstream iss(line);
     std::string mes, ip, razon;
     int dia, hora, minuto, segundo;
     std::string horaCompleta;

     iss >> mes >> dia >> horaCompleta >> ip;
     std::getline(iss, razon);

     std::replace(horaCompleta.begin(), horaCompleta.end(), ':', ' ');
     std::istringstream horaStream(horaCompleta);
     horaStream >> hora >> minuto >> segundo;

     return BitacoraEntry(mes, dia, hora, minuto, segundo, ip, razon);
 }

 int main() {
    std::cout << "hola" << std::endl;
     DoublyLinkedList<BitacoraEntry> bitacora;
     std::ifstream input("bitacoraData.txt");
     if (!input) {
         std::cerr << "No se pudo abrir el archivo de entrada.\n";
         return 1;
     }

     std::string line;
     while (std::getline(input, line)) {
         if (!line.empty()) {
             bitacora.addLast(parseLine(line));
         }
     }

     input.close();

     bitacora.mergeSort();


     std::ofstream salida("bitacora_ordenada.txt");
     bitacora.print(salida);
     salida.close();

     std::cout << "Ingresa la fecha de inicio (Ej: Jun 01 00:22:36):\n";
     std::string mesIni, mesFin;
     int diaIni, hIni, mIni, sIni;
     int diaFin, hFin, mFin, sFin;

     std::cin >> mesIni >> diaIni >> hIni;
     std::cin.ignore(); std::cin >> mIni;
     std::cin.ignore(); std::cin >> sIni;

     std::cout << "Ingresa la fecha de fin (Ej: Jun 01 08:23:52):\n";
     std::cin >> mesFin >> diaFin >> hFin;
     std::cin.ignore(); std::cin >> mFin;
     std::cin.ignore(); std::cin >> sFin;

     BitacoraEntry ini(mesIni, diaIni, hIni, mIni, sIni, "", "");
     BitacoraEntry fin(mesFin, diaFin, hFin, mFin, sFin, "", "");

     std::ofstream resultados("resultado_busqueda.txt");
     if (!resultados) {
         std::cerr << "No se pudo crear el archivo de resultados.\n";
         return 1;
     }

     bitacora.searchRange(ini, fin, std::cout);
     bitacora.searchRange(ini, fin, resultados);

     resultados.close();

     return 0;
 }
