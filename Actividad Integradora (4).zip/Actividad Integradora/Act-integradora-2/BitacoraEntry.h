/*
 * Archivo: BitacoraEntry.h
 * Autor: Samuel Rincón V. - A01752573
 * Actividad Integradora 2
 * Fecha: 7 de abril de 2025
 * 
 * Fuentes :
 * - GeeksforGeeks: https://www.geeksforgeeks.org/convert-string-time-tm-structure-c/
 * - GeeksforGeeks: https://www.geeksforgeeks.org/operator-overloading-cpp/
 * - cppreference: https://en.cppreference.com/w/cpp/io/basic_ostringstream
 * - cplusplus.com: https://cplusplus.com/reference/iomanip/
 * - Microsoft Learn: https://learn.microsoft.com/en-us/cpp/c-runtime-library/reference/tm-structure
 * - Stack Overflow: https://stackoverflow.com/questions/5040186/comparing-times-in-c-using-struct-tm
 * - IBM Docs: https://www.ibm.com/docs/en/zos/2.4.0?topic=functions-mktime-convert-broken-down-time-calendar-time
 */


#ifndef BITACORAENTRY_H
#define BITACORAENTRY_H

#include <string>
#include <ctime>
#include <sstream>
#include <iomanip>



class BitacoraEntry {
private:
    std::string mes;
    int dia, hora, minuto, segundo;
    std::string ip, razon;

public:
    BitacoraEntry();
    BitacoraEntry(std::string m, int d, int h, int min, int s, std::string ipStr, std::string reason);

    std::string toString() const;
    std::string getFechaCompleta() const;
    time_t toTimeT() const;

    bool operator > (const BitacoraEntry& other) const;
    bool operator == (const BitacoraEntry& other) const;
    bool operator < (const BitacoraEntry& other) const;
};

int convertirMes(const std::string& mesStr);


// IMPLEMENTACION

BitacoraEntry::BitacoraEntry() : mes(""), dia(0), hora(0), minuto(0), segundo(0), ip(""), razon("") {}

BitacoraEntry::BitacoraEntry(std::string m, int d, int h, int min, int s, std::string ipStr, std::string reason)
    : mes(m), dia(d), hora(h), minuto(min), segundo(s), ip(ipStr), razon(reason) {}

std::string BitacoraEntry::toString() const {
    std::ostringstream oss;
    oss << mes << " " << std::setw(2) << std::setfill('0') << dia << " "
        << std::setw(2) << std::setfill('0') << hora << ":"
        << std::setw(2) << std::setfill('0') << minuto << ":"
        << std::setw(2) << std::setfill('0') << segundo << " "
        << ip << " " << razon;
    return oss.str();
}

std::string BitacoraEntry::getFechaCompleta() const {
    std::ostringstream oss;
    oss << mes << " " << std::setw(2) << std::setfill('0') << dia << " "
        << std::setw(2) << std::setfill('0') << hora << ":"
        << std::setw(2) << std::setfill('0') << minuto << ":"
        << std::setw(2) << std::setfill('0') << segundo;
    return oss.str();
}

time_t BitacoraEntry::toTimeT() const {
    struct tm fecha = {};
    fecha.tm_year = 2025 - 1900;
    fecha.tm_mon = convertirMes(mes) - 1;
    fecha.tm_mday = dia;
    fecha.tm_hour = hora;
    fecha.tm_min = minuto;
    fecha.tm_sec = segundo;
    return mktime(&fecha);
}

bool BitacoraEntry::operator>(const BitacoraEntry& other) const {
    return this->toTimeT() > other.toTimeT();
}

bool BitacoraEntry::operator==(const BitacoraEntry& other) const {
    return this->toTimeT() == other.toTimeT();
}

bool BitacoraEntry::operator<(const BitacoraEntry& other) const {
    return this->toTimeT() < other.toTimeT();
}

int convertirMes(const std::string& mesStr) {
    const std::string meses[12] = {
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };
    for (int i = 0; i < 12; ++i) {
        if (meses[i] == mesStr) return i + 1;
    }
    return 0;
}

#endif
