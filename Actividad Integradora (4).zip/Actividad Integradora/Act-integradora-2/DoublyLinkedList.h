/*
 * Archivo: DoublyLinkedList.h
 * Autor: Samuel Rincón V. - A01752573
 * Actividad Integradora 2
 * Fecha: 7 de abril de 2025
 * 
 * Fuentes:
 * - GeeksforGeeks: https://www.geeksforgeeks.org/merge-sort-for-doubly-linked-list/
 * - GeeksforGeeks: https://www.geeksforgeeks.org/doubly-linked-list/
 * - cppreference: https://en.cppreference.com/w/cpp/io/ostream
 * - TutorialsPoint: https://www.tutorialspoint.com/cplusplus/cpp_templates.htm
 */



#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

#include <iostream>
#include <fstream>

template <class T>
class DoublyLinkedList {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;
        Node(T d) : data(d), prev(nullptr), next(nullptr) {}
    };

    Node* head;
    Node* tail;
    int size;

    Node* mergeSort(Node* start);
    Node* merge(Node* first, Node* second);
    Node* findStart(const T& key);
    Node* findEnd(const T& key);

public:
    DoublyLinkedList();
    ~DoublyLinkedList();
    void addLast(const T& value);                    
    void mergeSort();                                
    void print(std::ostream& os);                    
    void searchRange(const T& start, const T& end, std::ostream& os); 
};

template <class T>
DoublyLinkedList<T>::DoublyLinkedList() : head(nullptr), tail(nullptr), size(0) {}

template <class T>
DoublyLinkedList<T>::~DoublyLinkedList() {
    Node* current = head;
    while (current) {
        Node* nextNode = current->next;
        delete current;
        current = nextNode;
    }
}

template <class T>
void DoublyLinkedList<T>::addLast(const T& value) {
    Node* newNode = new Node(value);
    if (!head) {
        head = tail = newNode;
    } else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    size++;
}

template <class T>
void DoublyLinkedList<T>::mergeSort() {
    head = mergeSort(head);
    tail = head;
    while (tail && tail->next) {
        tail = tail->next;
    }
}

template <class T>
typename DoublyLinkedList<T>::Node* DoublyLinkedList<T>::mergeSort(Node* start) {
    if (!start || !start->next) return start;

    Node* slow = start;
    Node* fast = start->next;

    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }

    Node* mid = slow->next;
    slow->next = nullptr;
    if (mid) mid->prev = nullptr;

    Node* left = mergeSort(start);
    Node* right = mergeSort(mid);

    return merge(left, right);
}

template <class T>
typename DoublyLinkedList<T>::Node* DoublyLinkedList<T>::merge(Node* first, Node* second) {
    if (!first) return second;
    if (!second) return first;

    if (first->data > second->data) {
        first->next = merge(first->next, second);
        if (first->next) first->next->prev = first;
        first->prev = nullptr;
        return first;
    } else {
        second->next = merge(first, second->next);
        if (second->next) second->next->prev = second;
        second->prev = nullptr;
        return second;
    }
}

template <class T>
void DoublyLinkedList<T>::print(std::ostream& os) {
    Node* current = head;
    while (current) {
        os << current->data.toString() << std::endl;
        current = current->next;
    }
}

template <class T>
typename DoublyLinkedList<T>::Node* DoublyLinkedList<T>::findStart(const T& key) {
    Node* current = head;
    while (current && current->data > key) {
        current = current->next;
    }
    if (current && current->data == key) return current;
    return nullptr;
}

template <class T>
typename DoublyLinkedList<T>::Node* DoublyLinkedList<T>::findEnd(const T& key) {
    Node* current = tail;
    while (current && current->data < key) {
        current = current->prev;
    }
    if (current && current->data == key) return current;
    return nullptr;
}

template <class T>
void DoublyLinkedList<T>::searchRange(const T& start, const T& end, std::ostream& os) {
    Node* ini = findStart(start);
    Node* fin = findEnd(end);
    if (!ini || !fin) {
        os << "Una o ambas fechas no fueron encontradas." << std::endl;
        return;
    }
    Node* current = ini;
    while (current != fin->next) {
        os << current->data.toString() << std::endl;
        current = current->next;
    }
}

#endif
